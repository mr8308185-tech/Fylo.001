import { useState } from "react";
import { useData } from "@/lib/store";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Phone, Lock, Mail, KeyRound, ShieldCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AuthPage() {
  const { login, signup } = useData();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = useState(false);

  const onLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const form = e.target as HTMLFormElement;
    const email = (form.elements.namedItem("email") as HTMLInputElement).value;
    const password = (form.elements.namedItem("password") as HTMLInputElement).value;

    setTimeout(() => {
      if (login(email, password)) {
        setLocation("/");
        toast({
          title: "تم تسجيل الدخول بنجاح",
          description: "مرحباً بك في نظام إدارة المدارس",
        });
      } else {
        toast({
          variant: "destructive",
          title: "خطأ في تسجيل الدخول",
          description: "البريد الإلكتروني أو كلمة المرور غير صحيحة",
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  const onSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const form = e.target as HTMLFormElement;
    const email = (form.elements.namedItem("signup-email") as HTMLInputElement).value;
    const password = (form.elements.namedItem("signup-password") as HTMLInputElement).value;
    const code = (form.elements.namedItem("code") as HTMLInputElement).value;

    setTimeout(() => {
      const result = signup(email, password, code);
      if (result.success) {
        setLocation("/");
        toast({
          title: "تم إنشاء الحساب",
          description: result.message,
        });
      } else {
        toast({
          variant: "destructive",
          title: "فشل إنشاء الحساب",
          description: result.message,
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 relative overflow-hidden" dir="rtl">
      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1580582932707-520aed937b7b?q=80&w=2064&auto=format&fit=crop')] bg-cover bg-center opacity-5 pointer-events-none"></div>
      
      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="text-center space-y-2">
          <div className="bg-white w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-slate-200 border border-slate-100">
            <ShieldCheck className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">نظام إدارة الحضور</h1>
          <p className="text-slate-500 font-medium">Eng. Omar - 01558521369</p>
        </div>

        <Card className="border border-slate-200 shadow-2xl shadow-slate-200/50 bg-white/95 backdrop-blur-sm">
          <CardContent className="pt-6">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6 bg-slate-100">
                <TabsTrigger value="login" className="font-bold">تسجيل الدخول</TabsTrigger>
                <TabsTrigger value="signup" className="font-bold">حساب جديد</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={onLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="font-bold text-slate-700">البريد الإلكتروني</Label>
                    <div className="relative">
                      <Mail className="absolute right-3 top-3 h-5 w-5 text-slate-400" />
                      <Input id="email" name="email" type="email" placeholder="example@school.com" className="pr-10 h-11 bg-slate-50 border-slate-200 focus:bg-white" required defaultValue="school1@gmail.com" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="font-bold text-slate-700">كلمة المرور / الهاتف</Label>
                    <div className="relative">
                      <KeyRound className="absolute right-3 top-3 h-5 w-5 text-slate-400" />
                      <Input id="password" name="password" type="password" placeholder="********" className="pr-10 h-11 bg-slate-50 border-slate-200 focus:bg-white" required defaultValue="01558521369" />
                    </div>
                  </div>
                  <Button type="submit" className="w-full h-12 text-base font-bold shadow-lg shadow-primary/25 mt-2" disabled={isLoading}>
                    {isLoading ? "جاري التحقق..." : "دخول للنظام"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={onSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-email" className="font-bold text-slate-700">البريد الإلكتروني</Label>
                    <div className="relative">
                      <Mail className="absolute right-3 top-3 h-5 w-5 text-slate-400" />
                      <Input id="signup-email" name="signup-email" type="email" placeholder="example@school.com" className="pr-10 h-11 bg-slate-50 border-slate-200 focus:bg-white" required />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password" className="font-bold text-slate-700">كلمة المرور</Label>
                    <div className="relative">
                      <KeyRound className="absolute right-3 top-3 h-5 w-5 text-slate-400" />
                      <Input id="signup-password" name="signup-password" type="password" placeholder="********" className="pr-10 h-11 bg-slate-50 border-slate-200 focus:bg-white" required />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="code" className="font-bold text-slate-700">كود التفعيل</Label>
                    <div className="relative">
                      <Lock className="absolute right-3 top-3 h-5 w-5 text-slate-400" />
                      <Input id="code" name="code" type="text" placeholder="أدخل كود التفعيل" className="pr-10 h-11 bg-slate-50 border-slate-200 focus:bg-white" required />
                    </div>
                    <p className="text-xs text-slate-500 font-medium">تواصل مع المطور للحصول على الكود</p>
                  </div>
                  <Button type="submit" className="w-full h-12 text-base font-bold shadow-lg shadow-primary/25 mt-2" disabled={isLoading}>
                    {isLoading ? "جاري الإنشاء..." : "إنشاء حساب"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="justify-center border-t border-slate-100 bg-slate-50 py-4">
            <div className="flex items-center gap-2 text-sm text-slate-500 font-medium">
              <Phone className="w-4 h-4" />
              <span>للدعم الفني: 01558521369</span>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}