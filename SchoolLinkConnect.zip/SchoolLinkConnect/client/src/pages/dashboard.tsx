import { useState } from "react";
import { useData } from "@/lib/store";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Plus, School, Trash2, Search, GraduationCap, Users, LayoutDashboard } from "lucide-react";
import { Layout } from "@/components/layout";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function Dashboard() {
  const { schools, addSchool, removeSchool } = useData();
  const [newSchoolName, setNewSchoolName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredSchools = schools.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddSchool = () => {
    if (newSchoolName.trim()) {
      addSchool(newSchoolName);
      setNewSchoolName("");
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Hero Section */}
        <div className="relative overflow-hidden rounded-2xl bg-white border border-slate-200 shadow-sm p-8 sm:p-12">
          <div className="relative z-10">
            <h2 className="text-4xl font-black text-slate-900 mb-4">لوحة التحكم</h2>
            <p className="text-lg text-slate-600 font-medium max-w-2xl">
              مرحباً بك في نظام إدارة المدارس المتطور. قم بإدارة مدارس متعددة، طلاب، ودرجات بكل سهولة ويسر.
            </p>
          </div>
          <div className="absolute right-0 top-0 w-1/3 h-full bg-gradient-to-l from-slate-50 to-transparent pointer-events-none"></div>
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="relative flex-1 max-w-md w-full">
            <Search className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
            <Input 
              placeholder="بحث عن مدرسة..." 
              className="pr-10 h-11 bg-white border-slate-200 shadow-sm focus:border-primary focus:ring-primary/20"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button className="h-11 px-6 gap-2 shadow-lg shadow-primary/25 bg-primary hover:bg-blue-600 transition-all">
                <Plus className="w-5 h-5" />
                <span className="font-bold">إضافة مدرسة جديدة</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md bg-white border-slate-200" dir="rtl">
              <DialogHeader>
                <DialogTitle>إضافة مدرسة</DialogTitle>
                <DialogDescription>
                  أدخل اسم المدرسة الجديدة لإضافتها إلى النظام.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="font-bold text-slate-700">اسم المدرسة</Label>
                  <Input
                    id="name"
                    placeholder="مثال: مدرسة النور الثانوية"
                    value={newSchoolName}
                    className="bg-white"
                    onChange={(e) => setNewSchoolName(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter className="sm:justify-start">
                <DialogClose asChild>
                  <Button type="button" variant="secondary">
                    إلغاء
                  </Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button type="button" onClick={handleAddSchool} disabled={!newSchoolName.trim()}>
                    حفظ المدرسة
                  </Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {filteredSchools.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
            <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-100">
              <School className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">لا توجد مدارس حالياً</h3>
            <p className="text-slate-500 max-w-sm mx-auto mt-2 mb-6 font-medium">
              لم تقم بإضافة أي مدارس بعد. اضغط على زر "إضافة مدرسة" للبدء.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSchools.map((school) => (
              <Card key={school.id} className="group hover:shadow-xl hover:shadow-slate-200 transition-all duration-300 border-slate-200 bg-white overflow-hidden relative hover:-translate-y-1">
                <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                  <div className="bg-blue-50 p-2.5 rounded-xl group-hover:bg-blue-100 transition-colors">
                    <School className="w-6 h-6 text-primary" />
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-destructive -mt-1 -ml-2 hover:bg-destructive/10">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent dir="rtl" className="bg-white border-slate-200">
                      <DialogHeader>
                        <DialogTitle>حذف المدرسة؟</DialogTitle>
                        <DialogDescription>
                          هل أنت متأكد من رغبتك في حذف "{school.name}"؟ سيتم حذف جميع بيانات الطلاب والحضور المرتبطة بها نهائياً.
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter className="gap-2 sm:gap-0">
                        <DialogClose asChild>
                          <Button variant="secondary">إلغاء</Button>
                        </DialogClose>
                        <DialogClose asChild>
                          <Button variant="destructive" onClick={() => removeSchool(school.id)}>حذف نهائي</Button>
                        </DialogClose>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  <CardTitle className="text-xl mb-2 line-clamp-1 text-slate-900 font-bold" title={school.name}>
                    {school.name}
                  </CardTitle>
                  <div className="flex items-center gap-4 text-sm text-slate-500 mt-4 font-medium">
                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                      <Users className="w-4 h-4" />
                      <span>{school.students.length} طالب</span>
                    </div>
                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                      <LayoutDashboard className="w-4 h-4" />
                      <span>3 صفوف</span>
                    </div>
                  </div>
                  
                  <Link href={`/school/${school.id}`}>
                    <Button className="w-full mt-6 bg-slate-900 text-white hover:bg-slate-800 font-bold">
                      إدارة المدرسة
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}