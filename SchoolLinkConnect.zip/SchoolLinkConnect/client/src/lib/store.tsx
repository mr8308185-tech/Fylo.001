import { createContext, useContext, useEffect, useState } from "react";
import { nanoid } from "nanoid";

// Types
export type User = {
  id: string;
  email: string;
  name: string;
};

export type Student = {
  id: string;
  name: string;
  parentPhone: string;
  className: string; // "1st Secondary", "2nd Secondary", "3rd Secondary"
  totalGrade?: number;
  obtainedGrade?: number;
};

export type School = {
  id: string;
  name: string;
  students: Student[];
  attendance: Record<string, Record<string, boolean>>; // date -> studentId -> isPresent (true=present, false=absent)
};

export type AppState = {
  currentUser: User | null;
  schools: School[];
};

type DataContextType = {
  user: User | null;
  schools: School[];
  login: (email: string, phonePass: string) => boolean;
  signup: (email: string, phonePass: string, code: string) => { success: boolean; message: string };
  logout: () => void;
  addSchool: (name: string) => void;
  removeSchool: (id: string) => void;
  addStudent: (schoolId: string, student: Omit<Student, "id">) => void;
  removeStudent: (schoolId: string, studentId: string) => void;
  updateStudent: (schoolId: string, student: Student) => void;
  markAttendance: (schoolId: string, date: string, studentId: string, isPresent: boolean) => void;
  getAttendance: (schoolId: string, date: string) => Record<string, boolean>;
};

const DataContext = createContext<DataContextType | undefined>(undefined);

const STORAGE_KEY = "school_attendance_app_v1";

// Initial Mock Data
const INITIAL_SCHOOLS: School[] = [
  {
    id: "demo-school-1",
    name: "مدرسة النور الثانوية",
    students: [
      { id: "s1", name: "أحمد محمد", parentPhone: "201234567890", className: "الصف الأول الثانوي", totalGrade: 100, obtainedGrade: 95 },
      { id: "s2", name: "سارة علي", parentPhone: "201098765432", className: "الصف الثاني الثانوي", totalGrade: 100, obtainedGrade: 88 },
    ],
    attendance: {},
  },
];

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [schools, setSchools] = useState<School[]>([]);
  const [dataLoaded, setDataLoaded] = useState(false);

  // Load data on mount
  useEffect(() => {
    const storedUser = localStorage.getItem(`${STORAGE_KEY}_user`);
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
      
      // Load user-specific data
      const storedSchools = localStorage.getItem(`${STORAGE_KEY}_data_${parsedUser.email}`);
      if (storedSchools) {
        setSchools(JSON.parse(storedSchools));
      } else {
        setSchools([]);
      }
    }
    setDataLoaded(true);
  }, []);

  // Save data whenever it changes
  useEffect(() => {
    if (!dataLoaded || !user) return;
    localStorage.setItem(`${STORAGE_KEY}_data_${user.email}`, JSON.stringify(schools));
  }, [schools, user, dataLoaded]);

  const login = (email: string, phonePass: string) => {
    // Hardcoded credentials as requested
    if (email === "school1@gmail.com" && phonePass === "01558521369") {
      const newUser = { id: "admin", email, name: "Eng. Omar Admin" };
      setUser(newUser);
      localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(newUser));
      
      // Load data for this user if exists, else use initial/empty
      const storedSchools = localStorage.getItem(`${STORAGE_KEY}_data_${email}`);
      if (storedSchools) {
        setSchools(JSON.parse(storedSchools));
      } else {
        setSchools(INITIAL_SCHOOLS); // Give them some demo data first time
      }
      return true;
    }
    
    // Allow other logins if they exist in "database" (simulated by simply logging them in if they match format, 
    // but for this request specific credentials were asked. I will allow generic login for "other phones" simulation)
    // If it's not the master admin, we check if we have data for them? 
    // The user said "Login account I give you... if I want to create account I use code".
    
    // For simplicity, we'll assume any other login fails unless created via signup
    const storedAuth = localStorage.getItem(`${STORAGE_KEY}_auth_${email}`);
    if (storedAuth) {
      const authData = JSON.parse(storedAuth);
      if (authData.password === phonePass) {
         const newUser = { id: nanoid(), email, name: "مستخدم" };
         setUser(newUser);
         localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(newUser));
         const storedSchools = localStorage.getItem(`${STORAGE_KEY}_data_${email}`);
         setSchools(storedSchools ? JSON.parse(storedSchools) : []);
         return true;
      }
    }

    return false;
  };

  const signup = (email: string, phonePass: string, code: string) => {
    if (code !== "3200") {
      return { success: false, message: "كود إنشاء الحساب غير صحيح. تواصل مع المطور." };
    }
    
    // Check if exists
    if (localStorage.getItem(`${STORAGE_KEY}_auth_${email}`)) {
      return { success: false, message: "هذا الحساب موجود بالفعل" };
    }

    // Create auth record
    localStorage.setItem(`${STORAGE_KEY}_auth_${email}`, JSON.stringify({ password: phonePass }));
    
    // Auto login
    const newUser = { id: nanoid(), email, name: "مستخدم جديد" };
    setUser(newUser);
    localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(newUser));
    setSchools([]); // New accounts start empty
    
    return { success: true, message: "تم إنشاء الحساب بنجاح" };
  };

  const logout = () => {
    setUser(null);
    setSchools([]);
    localStorage.removeItem(`${STORAGE_KEY}_user`);
  };

  const addSchool = (name: string) => {
    setSchools((prev) => [...prev, { id: nanoid(), name, students: [], attendance: {} }]);
  };

  const removeSchool = (id: string) => {
    setSchools((prev) => prev.filter((s) => s.id !== id));
  };

  const addStudent = (schoolId: string, student: Omit<Student, "id">) => {
    setSchools((prev) =>
      prev.map((school) => {
        if (school.id === schoolId) {
          return {
            ...school,
            students: [...school.students, { ...student, id: nanoid() }],
          };
        }
        return school;
      })
    );
  };

  const removeStudent = (schoolId: string, studentId: string) => {
    setSchools((prev) =>
      prev.map((school) => {
        if (school.id === schoolId) {
          return {
            ...school,
            students: school.students.filter((s) => s.id !== studentId),
          };
        }
        return school;
      })
    );
  };
  
  const updateStudent = (schoolId: string, updatedStudent: Student) => {
    setSchools((prev) =>
      prev.map((school) => {
        if (school.id === schoolId) {
          return {
            ...school,
            students: school.students.map((s) => 
              s.id === updatedStudent.id ? updatedStudent : s
            ),
          };
        }
        return school;
      })
    );
  };

  const markAttendance = (schoolId: string, date: string, studentId: string, isPresent: boolean) => {
    setSchools((prev) =>
      prev.map((school) => {
        if (school.id === schoolId) {
          const dayAttendance = school.attendance[date] || {};
          return {
            ...school,
            attendance: {
              ...school.attendance,
              [date]: { ...dayAttendance, [studentId]: isPresent },
            },
          };
        }
        return school;
      })
    );
  };

  const getAttendance = (schoolId: string, date: string) => {
    const school = schools.find((s) => s.id === schoolId);
    return school?.attendance[date] || {};
  };

  return (
    <DataContext.Provider
      value={{
        user,
        schools,
        login,
        signup,
        logout,
        addSchool,
        removeSchool,
        addStudent,
        removeStudent,
        updateStudent,
        markAttendance,
        getAttendance,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}
