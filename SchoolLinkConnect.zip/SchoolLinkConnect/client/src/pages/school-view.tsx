import { useState, useMemo } from "react";
import { useRoute, useLocation } from "wouter";
import { useData, Student } from "@/lib/store";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { format, subDays, addDays } from "date-fns";
import { arEG } from "date-fns/locale";
import { 
  CalendarCheck, 
  Search, 
  Trash2, 
  MessageCircle, 
  ChevronRight, 
  ChevronLeft,
  CheckCircle2,
  XCircle,
  UserPlus,
  Edit,
  School,
  GraduationCap,
  User
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CLASSES = [
  "الصف الأول الثانوي",
  "الصف الثاني الثانوي",
  "الصف الثالث الثانوي",
];

export default function SchoolView() {
  const [, params] = useRoute("/school/:id");
  const [, setLocation] = useLocation();
  const { schools, addStudent, removeStudent, updateStudent, markAttendance, getAttendance } = useData();
  const { toast } = useToast();
  
  const schoolId = params?.id;
  const school = schools.find(s => s.id === schoolId);
  
  const [selectedClass, setSelectedClass] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [attendanceDate, setAttendanceDate] = useState(new Date());
  
  // Form States
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [isEditStudentOpen, setIsEditStudentOpen] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<Partial<Student>>({});
  
  if (!school) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold text-slate-900">المدرسة غير موجودة</h2>
          <Button onClick={() => setLocation("/")} className="mt-4">عودة للرئيسية</Button>
        </div>
      </Layout>
    );
  }

  const filteredStudents = school.students.filter(student => {
    const matchesClass = selectedClass === "all" || student.className === selectedClass;
    const matchesSearch = student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          student.parentPhone.includes(searchQuery);
    return matchesClass && matchesSearch;
  });

  const handleAddStudent = () => {
    if (currentStudent.name && currentStudent.className && currentStudent.parentPhone) {
      addStudent(school.id, currentStudent as Omit<Student, "id">);
      setIsAddStudentOpen(false);
      setCurrentStudent({});
      toast({ title: "تم إضافة الطالب بنجاح" });
    }
  };

  const handleUpdateStudent = () => {
    if (currentStudent.id && currentStudent.name && currentStudent.className && currentStudent.parentPhone) {
      updateStudent(school.id, currentStudent as Student);
      setIsEditStudentOpen(false);
      setCurrentStudent({});
      toast({ title: "تم تحديث بيانات الطالب" });
    }
  };

  const handleDeleteStudent = (studentId: string) => {
    if (confirm("هل أنت متأكد من حذف هذا الطالب؟")) {
      removeStudent(school.id, studentId);
      toast({ title: "تم حذف الطالب" });
    }
  };

  const handleMarkAttendance = (studentId: string, isPresent: boolean) => {
    const dateStr = format(attendanceDate, "yyyy-MM-dd");
    markAttendance(school.id, dateStr, studentId, isPresent);
  };

  const getWhatsAppLink = (student: Student) => {
    const message = `السلام عليكم، نود إبلاغكم أن الطالب ${student.name} تغيب عن الحضور اليوم ${format(attendanceDate, "dd/MM/yyyy")} في ${school.name}.`;
    return `https://wa.me/${student.parentPhone}?text=${encodeURIComponent(message)}`;
  };

  const attendanceData = getAttendance(school.id, format(attendanceDate, "yyyy-MM-dd"));

  const stats = {
    total: filteredStudents.length,
    present: filteredStudents.filter(s => attendanceData[s.id] === true).length,
    absent: filteredStudents.filter(s => attendanceData[s.id] === false).length,
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-slate-500 mb-1 text-sm font-medium">
              <School className="w-4 h-4" />
              <span>{school.name}</span>
            </div>
            <h1 className="text-2xl font-black text-slate-900">لوحة التحكم المدرسية</h1>
          </div>
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg border border-slate-200">
            {["all", ...CLASSES].map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${
                  selectedClass === cls 
                    ? "bg-white text-primary shadow-sm" 
                    : "text-slate-500 hover:text-slate-900 hover:bg-slate-200/50"
                }`}
              >
                {cls === "all" ? "الكل" : cls.replace("الصف ", "")}
              </button>
            ))}
          </div>
        </div>

        <Tabs defaultValue="attendance" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 bg-slate-100 p-1 h-auto border border-slate-200 rounded-xl">
            <TabsTrigger value="attendance" className="text-base py-3 font-bold data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm rounded-lg">تسجيل الحضور</TabsTrigger>
            <TabsTrigger value="students" className="text-base py-3 font-bold data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm rounded-lg">إدارة الطلاب</TabsTrigger>
            <TabsTrigger value="grades" className="text-base py-3 font-bold data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm rounded-lg">رصد الدرجات</TabsTrigger>
          </TabsList>

          {/* ATTENDANCE TAB */}
          <TabsContent value="attendance" className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => setAttendanceDate(prev => subDays(prev, 1))} className="border-slate-200 hover:bg-slate-50">
                  <ChevronRight className="w-4 h-4" />
                </Button>
                <div className="flex items-center gap-2 min-w-[180px] justify-center font-bold text-lg text-slate-900">
                  <CalendarCheck className="w-5 h-5 text-primary" />
                  <span>{format(attendanceDate, "EEEE, d MMMM", { locale: arEG })}</span>
                </div>
                <Button variant="outline" size="icon" onClick={() => setAttendanceDate(prev => addDays(prev, 1))} disabled={format(attendanceDate, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd")} className="border-slate-200 hover:bg-slate-50">
                  <ChevronLeft className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex items-center gap-6 text-sm font-bold bg-slate-50 px-6 py-3 rounded-lg border border-slate-200">
                <div className="text-slate-500">إجمالي: <span className="text-slate-900 text-lg">{stats.total}</span></div>
                <div className="text-emerald-600">حضور: <span className="text-lg">{stats.present}</span></div>
                <div className="text-rose-600">غياب: <span className="text-lg">{stats.absent}</span></div>
              </div>
            </div>

            <div className="grid gap-4">
              {filteredStudents.length === 0 ? (
                 <div className="text-center py-16 bg-white rounded-xl border border-dashed border-slate-300">
                   <div className="bg-slate-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <User className="w-8 h-8 text-slate-400" />
                   </div>
                   <p className="text-slate-500 text-lg font-medium">لا يوجد طلاب لعرضهم في هذا الصف</p>
                 </div>
              ) : (
                filteredStudents.map(student => {
                  const isPresent = attendanceData[student.id];
                  return (
                    <Card key={student.id} className={`transition-all duration-200 border-l-4 shadow-sm ${
                      isPresent === false ? "border-l-rose-500 bg-rose-50 border-y-rose-100 border-r-rose-100" : 
                      isPresent === true ? "border-l-emerald-500 bg-emerald-50 border-y-emerald-100 border-r-emerald-100" : 
                      "border-l-transparent hover:border-l-primary border-slate-200 bg-white"
                    }`}>
                      <div className="flex items-center justify-between p-4">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold shadow-sm ${
                            isPresent === false ? "bg-white text-rose-600 border border-rose-100" :
                            isPresent === true ? "bg-white text-emerald-600 border border-emerald-100" :
                            "bg-slate-100 text-slate-500"
                          }`}>
                            {student.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 text-lg">{student.name}</h3>
                            <p className="text-sm text-slate-500 font-medium">{student.className}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {isPresent === false && (
                            <a 
                              href={getWhatsAppLink(student)} 
                              target="_blank" 
                              rel="noopener noreferrer"
                            >
                              <Button size="sm" variant="outline" className="text-rose-600 border-rose-200 hover:bg-rose-50 hover:text-rose-700 gap-2 h-10 px-4 font-bold">
                                <MessageCircle className="w-4 h-4" />
                                <span className="hidden sm:inline">إرسال واتساب</span>
                              </Button>
                            </a>
                          )}
                          
                          <div className="flex bg-white rounded-lg border border-slate-200 p-1.5 shadow-sm">
                            <button
                              onClick={() => handleMarkAttendance(student.id, true)}
                              className={`p-2.5 rounded-md transition-all ${
                                isPresent === true 
                                  ? "bg-emerald-500 text-white shadow-md" 
                                  : "text-slate-400 hover:bg-slate-50 hover:text-slate-600"
                              }`}
                              title="حاضر"
                            >
                              <CheckCircle2 className="w-5 h-5" />
                            </button>
                            <div className="w-px bg-slate-200 mx-1.5 my-1"></div>
                            <button
                              onClick={() => handleMarkAttendance(student.id, false)}
                              className={`p-2.5 rounded-md transition-all ${
                                isPresent === false 
                                  ? "bg-rose-500 text-white shadow-md" 
                                  : "text-slate-400 hover:bg-slate-50 hover:text-slate-600"
                              }`}
                              title="غائب"
                            >
                              <XCircle className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          {/* STUDENTS TAB */}
          <TabsContent value="students" className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="بحث عن طالب..." 
                  className="pr-10 bg-white border-slate-200 focus:border-primary shadow-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <Dialog open={isAddStudentOpen} onOpenChange={setIsAddStudentOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2 shadow-lg shadow-primary/20 font-bold">
                    <UserPlus className="w-4 h-4" />
                    <span>إضافة طالب</span>
                  </Button>
                </DialogTrigger>
                <DialogContent dir="rtl" className="bg-white">
                  <DialogHeader>
                    <DialogTitle>إضافة طالب جديد</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label>اسم الطالب</Label>
                      <Input 
                        placeholder="الاسم ثلاثي" 
                        className="bg-white"
                        onChange={(e) => setCurrentStudent(prev => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>الصف الدراسي</Label>
                      <Select onValueChange={(val) => setCurrentStudent(prev => ({ ...prev, className: val }))}>
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="اختر الصف" />
                        </SelectTrigger>
                        <SelectContent dir="rtl">
                          {CLASSES.map(cls => <SelectItem key={cls} value={cls}>{cls}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>رقم ولي الأمر (واتساب)</Label>
                      <Input 
                        placeholder="مثال: 2010xxxxxxx" 
                        type="tel"
                        className="bg-white"
                        onChange={(e) => setCurrentStudent(prev => ({ ...prev, parentPhone: e.target.value }))}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleAddStudent}>حفظ البيانات</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-right">
                  <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-4">اسم الطالب</th>
                      <th className="p-4">الصف</th>
                      <th className="p-4">رقم ولي الأمر</th>
                      <th className="p-4 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredStudents.map((student) => (
                      <tr key={student.id} className="hover:bg-slate-50/80 group transition-colors">
                        <td className="p-4 font-bold text-slate-900">{student.name}</td>
                        <td className="p-4 text-slate-500 font-medium">{student.className}</td>
                        <td className="p-4 font-mono text-slate-600 font-medium" dir="ltr">{student.parentPhone}</td>
                        <td className="p-4">
                          <div className="flex items-center justify-center gap-2">
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="h-8 w-8 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              onClick={() => {
                                setCurrentStudent(student);
                                setIsEditStudentOpen(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="h-8 w-8 p-0 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                              onClick={() => handleDeleteStudent(student.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          {/* GRADES TAB */}
          <TabsContent value="grades" className="space-y-6">
             <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-6">
                <div className="relative flex-1 max-w-md w-full">
                  <Search className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
                  <Input 
                    placeholder="بحث عن طالب..." 
                    className="pr-10 bg-white border-slate-200"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-600 bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
                  <GraduationCap className="w-4 h-4 text-primary" />
                  <span>إدارة الدرجات والتقييم</span>
                </div>
             </div>

             <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                {filteredStudents.map(student => (
                  <Card key={student.id} className="bg-white border-slate-200 hover:shadow-md transition-all hover:border-primary/30">
                    <div className="p-5">
                       <div className="flex justify-between items-start mb-6">
                          <div>
                            <h3 className="font-bold text-slate-900 text-lg">{student.name}</h3>
                            <p className="text-xs font-bold text-slate-500 mt-1">{student.className}</p>
                          </div>
                          <div className="bg-blue-50 p-2 rounded-lg">
                             <GraduationCap className="w-5 h-5 text-blue-600" />
                          </div>
                       </div>
                       
                       <div className="space-y-5">
                          <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-1.5">
                                <Label className="text-xs font-bold text-slate-500">الدرجة العظمى</Label>
                                <Input 
                                  type="number" 
                                  className="h-10 bg-slate-50 border-slate-200 text-center font-bold text-slate-900 focus:bg-white" 
                                  placeholder="-"
                                  defaultValue={student.totalGrade}
                                  onBlur={(e) => {
                                    const val = parseInt(e.target.value);
                                    if (!isNaN(val)) updateStudent(school.id, { ...student, totalGrade: val });
                                  }}
                                />
                             </div>
                             <div className="space-y-1.5">
                                <Label className="text-xs font-bold text-slate-500">الدرجة المحصلة</Label>
                                <Input 
                                  type="number" 
                                  className={`h-10 bg-slate-50 border-slate-200 text-center font-bold text-lg focus:bg-white ${
                                    (student.obtainedGrade || 0) < (student.totalGrade || 100) / 2 ? "text-rose-600" : "text-emerald-600"
                                  }`}
                                  placeholder="-"
                                  defaultValue={student.obtainedGrade}
                                  onBlur={(e) => {
                                    const val = parseInt(e.target.value);
                                    if (!isNaN(val)) updateStudent(school.id, { ...student, obtainedGrade: val });
                                  }}
                                />
                             </div>
                          </div>
                          
                          <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-100">
                             <div 
                                className={`h-full rounded-full transition-all ${
                                   (student.obtainedGrade || 0) < (student.totalGrade || 100) / 2 ? "bg-rose-500" : "bg-emerald-500"
                                }`}
                                style={{ 
                                  width: `${Math.min(100, ((student.obtainedGrade || 0) / (student.totalGrade || 100)) * 100)}%` 
                                }}
                             />
                          </div>
                       </div>
                    </div>
                  </Card>
                ))}
             </div>
          </TabsContent>
        </Tabs>

        {/* Edit Dialog (Shared) */}
        <Dialog open={isEditStudentOpen} onOpenChange={setIsEditStudentOpen}>
          <DialogContent dir="rtl" className="bg-white">
            <DialogHeader>
              <DialogTitle>تعديل بيانات الطالب</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>اسم الطالب</Label>
                <Input 
                  value={currentStudent.name || ""}
                  className="bg-white"
                  onChange={(e) => setCurrentStudent(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>الصف الدراسي</Label>
                <Select 
                  value={currentStudent.className}
                  onValueChange={(val) => setCurrentStudent(prev => ({ ...prev, className: val }))}
                >
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="اختر الصف" />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    {CLASSES.map(cls => <SelectItem key={cls} value={cls}>{cls}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>رقم ولي الأمر</Label>
                <Input 
                  value={currentStudent.parentPhone || ""}
                  type="tel"
                  className="bg-white"
                  onChange={(e) => setCurrentStudent(prev => ({ ...prev, parentPhone: e.target.value }))}
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleUpdateStudent}>حفظ التعديلات</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}